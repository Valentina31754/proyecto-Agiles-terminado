/* codigo cambiar imagen de blusa
function change_image(image){
    var container = document.getElementById("main-image");
   container.src = image.src;
}
document.addEventListener("DOMContentLoaded", function(event) {
});
*/
/* Añadir al carrito */

var botonComprar = document.querySelectorAll(".btn-comprar");
const eliminarTodosPro = document.querySelector('.vacio');
const listaCarrito = document.querySelector('.carrito tbody');
const btnEliminarPro = document.querySelector('.borrar-producto');

cargarEventListeners();

function cargarEventListeners() {
     botonComprar.addEventListener('click', comprarProducto);
     btnEliminarPro.addEventListener('click', eliminarProCarrito);
     eliminarTodosPro.addEventListener('click', vaciarCarrito);
     document.addEventListener('DOMContentLoaded', leerLocalStorage);
}
function comprarProducto() {
    if(botonComprar.classList.contains('btn-comprar')){
         const proInfo = bontonComprar.parentElement.parentElement.parentElement;
         leerDatosProducto(proInfo);
         //console.log(proInfo)
    }
}


function leerDatosProducto(pro) {
    const productoInfo = {
         imagen: pro.querySelector('.imagen-pro').src,
         titulo: pro.querySelector('.titulo-pro').textContent,
         precio: pro.querySelector('.valor-pro').textContent,
         id: pro.querySelector('.btn-comprar').getAttribute('id')
    }
    insertarCarrito(productoInfo);
    //console.log(productoInfo)
}

function insertarCarrito(proCart) {
    const row = document.createElement('tr');
    row.innerHTML = `
         <td>
              <img src="${proCart.imagen}" width=100>
         </td>
         <td>${proCart.titulo}</td>
         <td>${proCart.precio}</td>
         <td>
              <a href="#" class="borrar-producto" id="${proCart.id}">X</a>
         </td>
    `;
    //console.log(row) 
    listaCarrito.appendChild(row);
    guardarProductoLocalStorage(proCart);
}